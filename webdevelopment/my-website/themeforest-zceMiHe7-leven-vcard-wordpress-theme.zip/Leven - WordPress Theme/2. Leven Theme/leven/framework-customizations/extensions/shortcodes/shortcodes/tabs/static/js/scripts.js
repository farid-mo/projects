(function($) { 
"use strict"; 
    $(document).ready(function ($) {
        $(".fw-tabs-container").tabs();
    });
})(jQuery);
