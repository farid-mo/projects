<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'         => esc_html__('Image', 'leven'),
		'description'   => esc_html__('Add an Image', 'leven'),
		'tab'           => esc_html__('Leven Media Elements', 'leven'),
		'popup_size'     => 'medium'
	)
);